package com.demo_with_kafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicDemoKafkaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
