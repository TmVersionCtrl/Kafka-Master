package com.demo_with_kafka.consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.demo_with_kafka.producer.User;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class Consumer {

//	@KafkaListener(topics = "simpleMessageTopic", groupId = "simpleMessageConsumerGroup")
//	public void consumeMessage(String message) {
//		log.info("Consuming the message-> "+message);
//	}
	
	@KafkaListener(topics = "user.topic", groupId = "userConsumerGroup")
	public void consumeUser(User user) {
		log.info("Consuming User-> "+user.toString());
	}
	
}
