package com.demo_with_kafka.producer;

import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/produce")
public class ProducerController {

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	
	@Autowired
	private KafkaTemplate<String, Object> userKafkaTemplate;
	
	@GetMapping("/message/{message}")
	public ResponseEntity<?> produceMsg(@PathVariable String message) {
		CompletableFuture<SendResult<String, String>> future = kafkaTemplate.send("simpleMessageTopic",message);
		future.whenComplete((result,ex)->{
			if(ex==null)
				log.info("Message sent-> "+message+" , with offset-> "+result.getRecordMetadata().offset());
			else
				log.error("Unable to send the message-> "+message+" reason "+ex.getMessage());
		});
		
		return new ResponseEntity<String>("Message sent successfully.",HttpStatus.OK);
	}
	
	@GetMapping("/bulk-message/{message}")
	public ResponseEntity<?> produceBulkMsg(@PathVariable String message) {
		CompletableFuture<SendResult<String, String>> future = null;
		for(int i=0;i<=1000;i++) {
			future = kafkaTemplate.send("simpleMessageTopic",message+":"+i);
			future.whenComplete((result,ex)->{
				if(ex==null)
					log.info("Message sent-> "+message+" , with offset-> "+result.getRecordMetadata().offset());
				else
					log.error("Unable to send the message-> "+message+" reason "+ex.getMessage());
			});
		}
		
		return new ResponseEntity<String>("Bulk Message's sent successfully.",HttpStatus.OK);
	}
	
	@PostMapping("/user")
	public  ResponseEntity<?> produceUser(@RequestBody User user) {
		log.info("in produceUser()::");
		CompletableFuture<SendResult<String, Object>> future = userKafkaTemplate.send("user.topic",user);
			future.whenComplete((result,ex)->{
				if(ex==null)
					log.info("User sent-> "+user.toString()+" , with offset-> "+result.getRecordMetadata().offset());
				else
					log.error("Unable to send the message-> "+user.toString()+" reason "+ex.getMessage());
			});
		
		return new ResponseEntity<String>("User sent successfully.",HttpStatus.OK);
	}
}
